﻿namespace ValidationDemoApi.CORE.Interfaces
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
